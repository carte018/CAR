#!/bin/sh -e

rm -f /etc/logrotate.conf
rm -f /etc/logrotate.d/syslog-ng

exit 0
